/* Keep JAMVERSYM in sync with VERSION. */
/* It can be accessed as $(JAMVERSION) in the Jamfile. */

#define VERSION "2.5.2"
#define JAMVERSYM "JAMVERSION=2.5.2"
